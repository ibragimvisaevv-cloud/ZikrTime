Approved by the user: Купол и горизонт, 2026-10-30.
Android application layers use these VectorDrawable sources. SVG files remain editable.
